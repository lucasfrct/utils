function Set-ConsoleStyle() {
    [CmdletBinding()] param ()

    cmd /c color A
}